﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EdukuJez.Repositories
{
    public class Subject : EntityBase
    {
        public String SubjectName { get; set; }
    }
}