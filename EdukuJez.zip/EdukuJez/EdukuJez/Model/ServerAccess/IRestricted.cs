﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EdukuJez
{
    public class IRestricted
    {
        public string ReqPermission { get; protected set; }
    }
}