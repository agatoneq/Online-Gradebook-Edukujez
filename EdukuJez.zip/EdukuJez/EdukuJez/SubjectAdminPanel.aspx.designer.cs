﻿//------------------------------------------------------------------------------
// <generowane automatycznie>
//     Ten kod został wygenerowany przez narzędzie.
//
//     Zmiany w tym pliku mogą spowodować niewłaściwe zachowanie i zostaną utracone
//     w przypadku ponownego wygenerowania kodu. 
// </generowane automatycznie>
//------------------------------------------------------------------------------

namespace EdukuJez
{


    public partial class SubjectAdminPanel
    {

        /// <summary>
        /// Kontrolka LabelSubjectName.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label LabelSubjectName;

        /// <summary>
        /// Kontrolka TextBoxSubjectName.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox TextBoxSubjectName;

        /// <summary>
        /// Kontrolka LabelDescription.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label LabelDescription;

        /// <summary>
        /// Kontrolka TextBoxSubjectDescription.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox TextBoxSubjectDescription;

        /// <summary>
        /// Kontrolka LabelGroupsAndUsers.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label LabelGroupsAndUsers;

        /// <summary>
        /// Kontrolka DropDownList.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList DropDownList;

        /// <summary>
        /// Kontrolka ButtonAdd.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button ButtonAdd;

        /// <summary>
        /// Kontrolka ListBox1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.ListBox ListBox1;

        /// <summary>
        /// Kontrolka ButtonDelete.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button ButtonDelete;

        /// <summary>
        /// Kontrolka ButtonSubjectAccept.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button ButtonSubjectAccept;
    }
}
